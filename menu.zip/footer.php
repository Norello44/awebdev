<div class="row footer cf">
		<div class="small-12 medium-12 large-12 columns">
			<!--Creative Commons License-->
			<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/2.5/" title="Questo sito è pubblicato sotto licenza Creative Commons"><img alt="Creative Commons License" style="border-width: 0" src="http://i.creativecommons.org/l/by-nc-sa/2.5/80x15.png"></a>
			<!--/Creative Commons License-->
			<!-- <rdf:RDF xmlns="http://web.resource.org/cc/" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:rdfs="http://www.w3.org/2000/01/rdf-schema#">
				<Work rdf:about="">
					<license rdf:resource="http://creativecommons.org/licenses/by-nc-sa/2.5/" />
				<dc:type rdf:resource="http://purl.org/dc/dcmitype/InteractiveResource" />
				</Work>
				<License rdf:about="http://creativecommons.org/licenses/by-nc-sa/2.5/"><permits rdf:resource="http://web.resource.org/cc/Reproduction"/><permits rdf:resource="http://web.resource.org/cc/Distribution"/><requires rdf:resource="http://web.resource.org/cc/Notice"/><requires rdf:resource="http://web.resource.org/cc/Attribution"/><prohibits rdf:resource="http://web.resource.org/cc/CommercialUse"/><permits rdf:resource="http://web.resource.org/cc/DerivativeWorks"/><requires rdf:resource="http://web.resource.org/cc/ShareAlike"/></License></rdf:RDF> -->
  		<br>joy.indivia.net
  		</div>
  	</div>