		<div class="row header">
		    <div class="small-12 medium-12 large-12 columns" id="header">
			    <a href="index.php" ><img src="img/logo-joy2.svg" class="transient-header" alt="Indivia.net: server vegetale a foglia lunga verde chiaro" /></a>
			</div>
		</div>
		<div class="row langsel">
			 <div class="small-12 medium-12 large-12 columns">
					<a hreflang="it" href='<?php $_SERVER['REQUEST_URI']?>?langs=it'>
						<img src="img/Flag_of_Italy.jpg" alt="IT" class="langsel"></a>&nbsp;
					<a hreflang="en" href='<?php $_SERVER['REQUEST_URI']?>?langs=en'>
						<img src="img/English.jpg" alt="EN" class="langsel"></a>
			</div>
		</div>