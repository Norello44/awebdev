<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta http-equiv="content-lang" content="en, it">
<meta name="description" content="Home page of Joy in Indivia">
<meta name="keywords" content="Information architecture, portfolio, agnese camellini, web design, bologna">
<title>--- ::: joy.indivia.net ::: ---</title>
<link rel='stylesheet' type='text/css' href='stylesheets/global.css'>
<link rel='stylesheet' type='text/css' href='stylesheets/indivia.css'>
<!-- <link rel="shortcut icon" type="image/png" href="icon.png"> -->
<link rel="apple-touch-icon" href="favicon.png"/>
<link rel="stylesheet" href="stylesheets/app.css" />
<script src="bower_components/modernizr/modernizr.js"></script>
<script src="bower_components/jquery-2.1.4.min/index.js"></script>
<script src="bower_components/foundation/js/foundation.min.js"></script>
<script src="bower_components/foundation/js/foundation/foundation.reveal.js"></script>
<script src="js/app.js"></script>
<script type="text/javascript" src="js/multicolor.js"></script>
